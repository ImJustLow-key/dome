/*
SQLyog Ultimate v12.3.1 (32 bit)
MySQL - 10.1.19-MariaDB : Database - oneblog
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`oneblog` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `oneblog`;

/*Table structure for table `bl_admin` */

DROP TABLE IF EXISTS `bl_admin`;

CREATE TABLE `bl_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `bl_admin` */

insert  into `bl_admin`(`id`,`username`,`password`) values 
(1,'我只是低调而已','5986167ba2be38716363db8967cf5269'),
(3,'123456','e35cf7b66449df565f93c607d5a81d09');

/*Table structure for table `bl_article` */

DROP TABLE IF EXISTS `bl_article`;

CREATE TABLE `bl_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL COMMENT '文章描述',
  `pic` varchar(60) DEFAULT NULL COMMENT '文章楼略图',
  `content` text COMMENT '内容',
  `time` int(10) DEFAULT NULL COMMENT '发布时间',
  `columnid` int(11) DEFAULT NULL COMMENT '栏目id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `bl_article` */

insert  into `bl_article`(`id`,`title`,`description`,`pic`,`content`,`time`,`columnid`) values 
(3,'大沙发是的发送到','阿斯顿发的说法是打发第三方',NULL,'阿斯顿发的说法都是',1518352719,3),
(4,'阿斯顿发的沙发斯蒂芬','阿范德萨发生大幅度',NULL,'嗷嗷待食发士大夫撒打发斯蒂芬',1518352736,2),
(5,'阿发送到发送到发送到','阿斯顿发送到发送到发的撒',NULL,'as发送到发送到发多少',1518352750,2),
(6,'打发第三方撒旦','阿斯顿发的说法都是发',NULL,'阿萨德发的所发生的',1518352774,3),
(7,'测试文章2','1、幸福是一种感觉。不依赖慑人的权势，不依赖过人的财富，不依赖超人的才华，依赖的是一颗平常心。幸福不可抢夺，只要心中有爱，幸福就会开敲门。 2、必须记住我们学习的时间是有限的。时间有限，不只由于人生短促，更由于人的纷繁。我们应该力求把我们所有的时间用去做','20180224\\675b8cc9b5070ea7a2600e32892dbdb9.jpg','<p><img src=\"http://img.baidu.com/hi/jx2/j_0002.gif\"/></p><p><br/></p>',1518411953,2),
(8,'沪深股市的','史蒂芬孙的方式地方史蒂芬孙的',NULL,'<p>士大夫都是发生的方式地方</p>',1518885788,3),
(11,'阿市斗法的师傅','阿萨德发生的飞洒地方','','<p>阿撒的法撒旦发生地方</p>',1519388348,3),
(12,'萨达萨达','按时大撒打算','','<p>按双打双打双打</p>',1519388808,0),
(13,'暗暗士大夫打算','敖德萨发生大幅','','<p>阿萨分撒地方士大夫</p>',1519390739,0),
(14,'阿三的发生','啊手动阀手动阀','20180224\\61b321da0daf39173c8fff77b1501c43.jpg','<p>爱的色放萨芬是打发士大夫是</p>',1519449744,3);

/*Table structure for table `bl_column` */

DROP TABLE IF EXISTS `bl_column`;

CREATE TABLE `bl_column` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(11) DEFAULT NULL COMMENT '栏目名称',
  `sort` int(5) DEFAULT '5' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `bl_column` */

insert  into `bl_column`(`id`,`name`,`sort`) values 
(2,'js1',8),
(3,'html',5);

/*Table structure for table `bl_comment` */

DROP TABLE IF EXISTS `bl_comment`;

CREATE TABLE `bl_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(255) DEFAULT NULL,
  `articleid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `bl_comment` */

insert  into `bl_comment`(`id`,`comment`,`articleid`,`userid`,`time`) values 
(1,'我',7,2,NULL),
(3,'我的天',7,2,NULL),
(4,'很好',7,2,NULL),
(5,'我的天',7,2,NULL),
(6,'我是天',7,2,NULL),
(7,'这是怎么回事',7,2,NULL),
(8,'我的天',7,2,NULL),
(9,'我',7,2,NULL),
(10,'很好',7,2,1518605023),
(11,'我不知道你叫什么啊',7,2,1518605033),
(12,'我只是低调而已',7,2,1518615695),
(13,'很好',7,2,1518796599),
(14,'我是人',7,2,1518799797);

/*Table structure for table `bl_label` */

DROP TABLE IF EXISTS `bl_label`;

CREATE TABLE `bl_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(11) DEFAULT NULL COMMENT '标签名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `bl_label` */

insert  into `bl_label`(`id`,`name`) values 
(2,'html'),
(3,'js'),
(5,'css'),
(6,'php'),
(7,'java'),
(8,'环境配置'),
(9,'服务器'),
(10,'我的天啊'),
(11,'标签'),
(12,'这是一个标签'),
(13,'标签哈哈哈');

/*Table structure for table `bl_link` */

DROP TABLE IF EXISTS `bl_link`;

CREATE TABLE `bl_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(11) DEFAULT NULL COMMENT '链接名称',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `sort` int(5) DEFAULT '5',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `bl_link` */

insert  into `bl_link`(`id`,`url`,`name`,`description`,`sort`) values 
(1,'baidu.com','百度','海大富',3),
(2,'www.taobao.com','淘宝','水电费第三方',4),
(4,'www.baidu1.com','html','水电费是的范德萨',5),
(7,'https://www.kancloud.cn/manual/thinkphp5/129356','thinkphp','',5);

/*Table structure for table `bl_message` */

DROP TABLE IF EXISTS `bl_message`;

CREATE TABLE `bl_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL COMMENT '消息内容',
  `time` int(10) DEFAULT NULL COMMENT '时间措',
  `userid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

/*Data for the table `bl_message` */

insert  into `bl_message`(`id`,`content`,`time`,`userid`) values 
(1,'我',1519051515,2),
(2,'奥的斯富士达',1519051725,2),
(3,'我',1519053834,2),
(4,'你好',1519053842,2),
(5,'我',1519053863,2),
(6,'你好',1519053876,2),
(7,'你好',1519053892,2),
(8,'你好',1519053929,2),
(9,'你好',1519053932,2),
(10,'你好',1519053935,2),
(11,'你好',1519053966,2),
(12,'我',1519054010,2),
(13,'的说法撒旦发生的非',1519054064,2),
(14,'物品的 ',1519054101,2),
(15,'我的',1519054702,2),
(16,'你哈  奥德赛发生大',1519054752,2),
(17,'',1519054966,2),
(20,'我知道你很好',1519055001,2),
(21,'你好',1519056175,2),
(22,'我只是',1519056532,2),
(23,'我的',1519056635,2),
(24,'我的人',1519056669,2),
(25,'我的',1519057135,2),
(26,'什么破网站',1519063889,2),
(27,'垃圾',1519097505,2),
(28,'我只是',1519294792,2);

/*Table structure for table `bl_user` */

DROP TABLE IF EXISTS `bl_user`;

CREATE TABLE `bl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) DEFAULT NULL,
  `userpassword` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `bl_user` */

insert  into `bl_user`(`id`,`username`,`userpassword`) values 
(1,'用户名','123456'),
(2,'我只是低调而已','123456');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
