<?php
namespace app\admin\controller;
use \think\Controller;
use \think\Request;
use \think\Validate;
use app\admin\model\Article as Articlem;


class Article extends Common
{
    public function index()
    {
    	// $article=db('article')->select();

      
      $article = Articlem::with('column')->order('id desc')->paginate(5);
        // 获取分页显示
        $page = $article->render();
        $list=$article->toArray();
        $this->assign('list',$list['data']);
        $this->assign('page', $page);
      return $this->fetch();
    }



    // 关键词搜索
    function search(){

        $q=input('q');
        $where['title|description']=array('like',"%".$q."%");

         $article = Articlem::where($where)->with('column')->paginate(5);

      //  $article=db('article')->where($where)->paginate(5);
        $page = $article->render();

        $article=$article->toArray();
         $data=$article['data'];
        foreach ($data as &$v) {
          $v['title']=preg_replace("/($q)/i", "<span style='color:red'>$q</span>", $v['title']);
          $v['description']=preg_replace("/($q)/i", "<span style='color:red'>$q</span>", $v['description']);
        }

        $this->assign('list',$data);
        $this->assign('page', $page);
       
        return $this->fetch('article/index');


    }

    public function upload(){
    // 获取表单上传文件 例如上传了001.jpg
    $file = request()->file('file');

   // $this->success($file,'',true);
   // 移动到框架应用根目录/public/uploads/ 目录下
    if($file){
        $info = $file->move(ROOT_PATH . 'public' . DS . 'static'.DS .'uploads');
        if($info){
            // 成功上传后 获取上传信息
            // 输出 jpg
            //echo $info->getExtension();
            // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
          
            echo $info->getSaveName();
            // 输出 42a79759f284b767dfcb2a0197904287.jpg
           // echo $info->getFilename(); 
        }else{
            // 上传失败获取错误信息
            echo $file->getError();
        }
    }
}




   
    // 添加
    function add(){

     
           
        if (Request::instance()->isPost()) {

        	$rule = [
			    'title'  => 'require|unique:article',
                 'content'  => 'require',
			];

			$msg = [
			    'title.require' => '文章名称必须',
			    'title.unique' => '文章名称已经存在',
                'content.require' => '内容必须',
			];

            $validate = new Validate($rule,$msg);
			$data = [
			    'title'  => input('post.title'),
                'description'  => input('post.description'),
                'columnid'  => input('post.columnid'),
                'content'  => input('post.content'),
                'time'  => time(),
                'pic'=>input('post.articeimg')
               // pic
			];
			if (!$validate->check($data)) {
			    $this->error($validate->getError());
			}else{
				$id=db('article')->insert($data);
				if ($id) {
					$this->success('添加成功');
				}else{
					$this->error('添加失败');
				}
			}


        }
         $column=db('column')->select();
        $this->assign('column',$column);
         return $this->fetch();
    }

    // 删除
    function del(){
    	$id=db('article')->delete(input('id'));

        $id1=db('comment')->where(['articleid'=>input('id')])->delete();


    	if ($id) {
    		$this->success('删除成功');
    	}else{
    		$this->error('删除失败');
    	}
    }

    // 修改
    function alter(){
 if (Request::instance()->isPost()) {

            $rule = [
                'title'  => 'require',
                 'content'  => 'require',
            ];

            $msg = [
                'title.require' => '文章名称必须',
                'content.require' => '内容必须',
            ];

            $validate = new Validate($rule,$msg);
            $data = [
                'title'  => input('post.title'),
                'description'  => input('post.description'),
                'columnid'  => input('post.columnid'),
                'content'  => input('post.content'),
                 'pic'=>input('post.articeimg')
               // pic
            ];
            if (!$validate->check($data)) {
                $this->error($validate->getError());
            }else{
               $id=db('Article')->where('id',input('post.id'))->update($data);
                if ($id) {
                    $this->success('修改成功');
                }else{
                    $this->error('修改失败');
                }
            }


        }


        $find=db('Article')->where(['id'=>input('id')])->find();
        $this->assign('find',$find);
       
        $column=db('column')->select();
        $this->assign('column',$column);
      
         return $this->fetch();

    }

     
    



}
