<?php
namespace app\admin\controller;
use \think\Controller;
use \think\Request;
use \think\Validate;
use app\index\model\Message as Messagem;

class Message extends Common
{
  

  
    
    // 全部留言板
    function index(){
        
       $Messagem = new Messagem();
        // 查询数据集
        $Message=$Messagem->with('user')->order('id desc')->paginate(5);
         $page = $Message->render();
        $this->assign('list',$Message);
        $this->assign('page', $page);
        

        return $this->fetch();

    }
   


    // 删除
    function del(){
      $id=db('Message')->delete(input('id'));
      if ($id) {
        $this->success('删除成功');
      }else{
        $this->error('删除失败');
      }
    }




}


