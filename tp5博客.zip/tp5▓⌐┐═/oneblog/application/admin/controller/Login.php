<?php
namespace app\Admin\controller;
use \think\Controller;
use \think\Request;
use \think\Validate;
use app\index\model\Comment as Commentm;


class Login extends Controller
{

  public function index(){
       if (Request::instance()->isPost()) {

         $rule = [
          'username'  => 'require',
          'password'  => 'require',
          'captcha|验证码'=>'require|captcha'
        ];

      $msg = [
          'username.require' => '用户名不能为空',
          'password.require' => '密码不能为空',
      ];

       $validate = new Validate($rule,$msg);
      $data = [
          'username'  => input('post.username'),
          'password'  => md5(input('post.password')),
          'captcha'   => input('post.captcha')
      ];


     
      if (!$validate->check($data)) {
          $this->error($validate->getError());
      }else{
           
         $id=db('admin')->where(['username'=>input('post.username'),'password'=>md5(input('post.password'))])->find();
      
        if ($id) {
          session('id', $id['id']);
          session('username', $id['username']);
          $this->success('登陆成功','Index/index');
        }else{
          $this->error('登陆失败');
        }
      }
        }

       // var_dump(md5('xiaoyao1995'));
        return $this->fetch();
        
    }


  




}


