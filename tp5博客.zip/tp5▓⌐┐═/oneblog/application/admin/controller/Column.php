<?php
namespace app\admin\controller;
use \think\Controller;
use \think\Request;
use \think\Validate;

class Column extends Common
{
    public function index()
    {
    	$column=db('Column')->order('sort asc')->select();
        
        $this->assign('list',$column);
        return $this->fetch();
    }
   
    // 添加
    function add(){
           
        if (Request::instance()->isPost()) {

        	$rule = [
			    'name'  => 'require|unique:Column',
			];

			$msg = [
			    'name.require' => '栏目名称必须',
			    'name.unique' => '栏目名称已经存在',
			];

            $validate = new Validate($rule,$msg);
			$data = [
			    'name'  => input('post.name')
			];
			if (!$validate->check($data)) {
			    $this->error($validate->getError());
			}else{
				$id=db('Column')->insert($data);
				if ($id) {
					$this->success('添加成功');
				}else{
					$this->error('添加失败');
				}
			}


        }
         return $this->fetch();
    }

    // 删除
    function del(){
    	$id=db('Column')->delete(input('id'));
    	if ($id) {
    		$this->success('删除成功');
    	}else{
    		$this->error('删除失败');
    	}
    }

    // 修改
    function alter(){


    	 if (Request::instance()->isPost()) {

        	$rule = [
			    'name'  => 'require|unique:Column',
			];

			$msg = [
			    'name.require' => '栏目名称必须',
			    'name.unique' => '栏目名称已经存在',
			];

            $validate = new Validate($rule,$msg);
			$data = [
			    'name'  => input('post.name')
			];
			if (!$validate->check($data)) {
			    $this->error($validate->getError());
			}else{
				$id=db('Column')->where(['id'=>input('id')])->update($data);
				if ($id) {
					$this->success('修改成功');
				}else{
					$this->error('修改失败');
				}
			}


        }

        $columnfind=db('column')->where(['id'=>input('id')])->find();
        $this->assign('columnfind',$columnfind);
      
         return $this->fetch();

    }

     
      // 排序
      public function sort(){

        foreach ($_POST as $id => $sort) {
            db('column')->where(array('id'=>$id))->setField('sort',$sort);
        }

        $this->success('排序成功！');

    }



}
