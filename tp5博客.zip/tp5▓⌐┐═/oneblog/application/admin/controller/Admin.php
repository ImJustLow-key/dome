<?php
namespace app\Admin\controller;
use \think\Controller;
use \think\Request;
use \think\Validate;
use app\index\model\Comment as Commentm;


class Admin extends Common
{

  
  function index(){

     $admin=db('admin')->select();
        
        $this->assign('list',$admin);

  
      return $this->fetch();
  }


  function add(){
    

     if (Request::instance()->isPost()) {

         $rule = [
          'username'  => 'require|unique:Admin',
          'password'  => 'require',
        ];

      $msg = [
          'username.require' => '用户名不能为空',
          'password.require' => '密码不能为空',
          'username.unique' => '用户名已经存在',
          
      ];

       $validate = new Validate($rule,$msg);
      $data = [
          'username'  => input('post.username'),
          'password'  => md5(input('post.password'))
      ];


      if (!$validate->check($data)) {
          $this->error($validate->getError());
      }else{
           
        $id= db('admin')->insert($data);
      
        if ($id) {
          $this->success('添加成功');
        }else{
          $this->error('添加失败');
        }
      }
        }



    return $this->fetch();
  }


   // 删除
    function del(){
      $id=db('admin')->delete(input('id'));
      if ($id) {
        $this->success('删除成功');
      }else{
        $this->error('删除失败');
      }
    }
   

   function alter(){


      if (Request::instance()->isPost()) {

         $rule = [
          'password'  => 'require',
        ];

      $msg = [
          'password.require' => '密码不能为空',
          
      ];

       $validate = new Validate($rule,$msg);
      $data = [
          'password'  => md5(input('post.password'))
      ];


      if (!$validate->check($data)) {
          $this->error($validate->getError());
      }else{
           
      
        $id= db('admin')->where('id',input('id'))->update($data);


        if ($id) {
          $this->success('修改成功');
        }else{
          $this->error('修改失败');
        }
      }
        }




      $id=db('admin')->find(input('id'));

      $this->assign('find',$id);
      return $this->fetch();
   }

  
  function outlogin(){
     session(null);
     $this->redirect('Login/index');
  }




}


