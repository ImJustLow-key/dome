<?php
namespace app\admin\controller;
use \think\Controller;
use \think\Request;
use \think\Validate;

class Link extends Common
{
    public function index()
    {
    	$link=db('Link')->order('sort asc')->select();
        
        $this->assign('list',$link);
        return $this->fetch();
    }
   
    // 添加
    function add(){
           
        if (Request::instance()->isPost()) {

        	$rule = [
			    'name'  => 'require|unique:Link',
                'url'  => 'require|unique:Link|url',
			];

			$msg = [
			    'name.require' => '链接名不能为空',
			    'name.unique' => '链接名称已经存在',
                'url.require' => '链接必须',
                'url.unique' => '链接已经存在',
                'url.url' => '非法的链接',
                    
			];

            $validate = new Validate($rule,$msg);
			$data = [
			    'name'  => input('post.name'),
                'url'  => input('post.url'),
                'description'=>input('post.description')
			];
			if (!$validate->check($data)) {
			    $this->error($validate->getError());
			}else{
				$id=db('link')->insert($data);
				if ($id) {
					$this->success('添加成功');
				}else{
					$this->error('添加失败');
				}
			}


        }
         return $this->fetch();
    }

    // 删除
    function del(){
    	$id=db('link')->delete(input('id'));
    	if ($id) {
    		$this->success('删除成功');
    	}else{
    		$this->error('删除失败');
    	}
    }

    // 修改
    function alter(){

        
        if (Request::instance()->isPost()) {

            $rule = [
                'name'  => 'require',
                'url'  => 'require|activeUrl',
            ];

            $msg = [
                'name.require' => '链接名不能为空',
                'url.require' => '链接必须',
                'url.activeUrl' => '非法的链接',
                    
            ];

            $validate = new Validate($rule,$msg);
            $data = [
                'name'  => input('post.name'),
                'url'  => input('post.url'),
                'description'=>input('post.description')
            ];
            if (!$validate->check($data)) {
                $this->error($validate->getError());
            }else{
               $id=db('link')->where(['id'=>input('id')])->update($data);
                if ($id) {
                    $this->success('修改成功');
                }else{
                    $this->error('修改失败');
                }
            }


        }

    	

        $find=db('link')->where(['id'=>input('id')])->find();
        $this->assign('find',$find);
       
         return $this->fetch();

    }

     
      // 排序
      public function sort(){

        foreach ($_POST as $id => $sort) {
            db('link')->where(array('id'=>$id))->setField('sort',$sort);
        }

        $this->success('排序成功！');

    }



}
