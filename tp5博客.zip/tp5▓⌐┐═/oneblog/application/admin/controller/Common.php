<?php
namespace app\Admin\controller;
use \think\Controller;

class Common extends Controller
{
      public function __construct(){
        parent::__construct();
        if(!session('id')){
            $this->error('请先登录系统！','Login/index');
        }
    }





}


