<?php
namespace app\admin\controller;
use \think\Controller;
use \think\Request;
use \think\Validate;

class Label extends Common
{
    public function index()
    {
    	$label=db('label')->paginate(5);
        // 获取分页显示
        $page = $label->render();
      
        $this->assign('list',$label);
        $this->assign('page', $page);
        return $this->fetch();
    }
   
    // 添加
    function add(){
           
        if (Request::instance()->isPost()) {

        	$rule = [
			    'name'  => 'require|unique:label',
			];

			$msg = [
			    'name.require' => '标签名不能为空',
			    'name.unique' => '标签名称已经存在',
                    
			];

            $validate = new Validate($rule,$msg);
			$data = [
			    'name'  => input('post.name')
			];
			if (!$validate->check($data)) {
			    $this->error($validate->getError());
			}else{
				$id=db('label')->insert($data);
				if ($id) {
					$this->success('添加成功');
				}else{
					$this->error('添加失败');
				}
			}


        }
         return $this->fetch();
    }

    // 删除
    function del(){
    	$id=db('label')->delete(input('id'));
    	if ($id) {
    		$this->success('删除成功');
    	}else{
    		$this->error('删除失败');
    	}
    }

    // 修改
    function alter(){

        
        if (Request::instance()->isPost()) {

           $rule = [
                'name'  => 'require|unique:label',
            ];

            $msg = [
                'name.require' => '标签名不能为空',
                'name.unique' => '标签名称已经存在',
                    
            ];

            $validate = new Validate($rule,$msg);
            $data = [
                'name'  => input('post.name')
            ];
            if (!$validate->check($data)) {
                $this->error($validate->getError());
            }else{
               $id=db('label')->where(['id'=>input('id')])->update($data);
                if ($id) {
                    $this->success('修改成功');
                }else{
                    $this->error('修改失败');
                }
            }


        }

    	

        $find=db('label')->where(['id'=>input('id')])->find();
        $this->assign('find',$find);
       
         return $this->fetch();

    }

     
 


}
