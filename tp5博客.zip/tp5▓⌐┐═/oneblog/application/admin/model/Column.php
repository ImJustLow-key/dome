<?php
namespace app\admin\model;

use think\Model;

class Column extends Model 
{
   
   public $name='column';
    public function article()
    {
        return $this->hasMany('article','id','id');
    }
   
   

}