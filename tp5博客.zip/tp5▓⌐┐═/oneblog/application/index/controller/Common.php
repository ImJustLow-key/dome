<?php
namespace app\index\controller;
use \think\Controller;

class Common extends Controller
{
    public function _initialize()
    {
       $this->nav();
       $this->link();
       $this->right();
    }



    public function nav(){
    	$column=db('Column')->order('sort asc')->select();
        $this->assign('column',$column);
    }

    public function link(){

    	$link=db('Link')->order('sort asc')->select();
    	$template='';
    	for ($i=0; $i < count($link); $i++) { 
    		
    		 if ($i==0) {
    		 	 $template .='<div class="col-lg-2"><h2>友情链接</h2><ul>';
    		 }else{
    		 	 if ($i%2==0) {
	    		 	$template .=' </ul></div>';
	    		 	if ($i < count($link)) {
	    		 		$template .='<div class="col-lg-2"><h2><br></h2><ul>';
	    		 	}
	    		 }
    		 }
             
              $template .="<li><a href='". $link[$i]["url"] ."' target='_blank'>".$link[$i]["name"]."</a></li>";
             
    	}
        
       
        $this->assign('template',$template);
                    
               
    }

    public function right(){

    	$rightarticle=db('article')->order('id desc')->paginate(10);
       
    
        $this->assign('rightarticle', $rightarticle);
        
    }



}


