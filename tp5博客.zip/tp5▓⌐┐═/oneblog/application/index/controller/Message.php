<?php
namespace app\index\controller;
use \think\Controller;
use \think\Request;
use \think\Validate;
use app\index\model\Message as Messagem;

class Message extends Common
{
   // 添加
   function add(){
      
      if (!session('userid')) {
         $this->error('失败','',true);
      }
     $data = [
                'content'  => input('post.content'),
                'time'  => time(),
                'userid'  => session('userid')
            ];
       $id=db('message')->insert($data);
       if ($id) {
           $this->success('成功','',true);
       }
   }


     // 获取
    function getmessage(){
        
  
        $Messagem = new Messagem();
        // 查询数据集
        $Message=$Messagem->with('user')->order('id desc')->paginate(10);
       
       $this->success($Message,'',true);

    }
    
    // 全部留言板
    function allmessage(){
        

       $Messagem = new Messagem();
        // 查询数据集
        $Message=$Messagem->with('user')->order('id desc')->paginate(10);
         $page = $Message->render();
        $this->assign('list',$Message);
        $this->assign('page', $page);

        return $this->fetch();

    }


  


}


