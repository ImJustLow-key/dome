<?php
namespace app\index\controller;

class Index extends Common
{
    public function index()
    {

    	$indexarticle=db('article')->order('id desc')->paginate(10);
        $this->assign('list', $indexarticle);
        return $this->fetch();

    }
    
   


}
