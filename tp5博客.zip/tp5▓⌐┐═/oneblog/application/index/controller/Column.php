<?php
namespace app\index\controller;

class Column extends Common
{
    public function index()
    {

    	$article=db('article')->where(['columnid'=>input('id')])->paginate(5);
        // 获取分页显示
        $page = $article->render();
        $this->assign('list',$article);
        $this->assign('page', $page);
        $Column=db('Column')->where(['id'=>input('id')])->find();
        $name=$Column['name'];
        $this->assign('name', $name);
        return $this->fetch();

    }


}
