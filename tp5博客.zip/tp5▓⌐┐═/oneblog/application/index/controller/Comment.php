<?php
namespace app\index\controller;
use \think\Controller;
use \think\Validate;
use app\index\model\Comment as Commentm;

class Comment extends Controller
{
   // 添加评论
   function add(){
      $rule = [
          'comment'  => 'require',
          'articleid'=> 'require',
          'userid'=> 'require',
      ];

      $msg = [
          'comment.require' => '评论不能为空'
      ];

      $validate = new Validate($rule,$msg);
       $data = [
                'comment'  => input('post.comment'),
                'articleid'  => input('post.articleid'),
                'userid'  => input('post.userid'),
                'time'  => time(),
            ];
      if (!$validate->check($data)) {
          $this->error($validate->getError());
      }else{
           $id=db('comment')->insert($data);
           if ($id) {
              $this->success('评论成功');
           }else{
               $this->error('评论失败');

           }
      }
   }

     

      // 获取评论
    function getcomment(){
        
        $count=5;
        $page=input('page')-1;
       $page=$page*$count;
       
       // $this->success($page,'',true);
        $comment = new Commentm();
        // 查询数据集
        $comment=$comment->where('articleid', input('articleid'))->with('user')->order('id desc')->limit($page,$count)->select();
       $this->success($comment,'',true);

    }

 





}


