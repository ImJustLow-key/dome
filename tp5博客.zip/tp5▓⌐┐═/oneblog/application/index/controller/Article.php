<?php
namespace app\index\controller;
use app\index\model\Article as Articlem;

class Article extends Common
{
    public function index()
    {
     
     $Articlem = new Articlem();
    	$article = $Articlem -> where('id', input('id'))->with('column')->find()->toArray();

   
       $this->assign('article', $article);
        return $this->fetch();

    }
   
   // 关键词搜索
    function search(){

        $q=input('q');
        $where['title|description']=array('like',"%".$q."%");
        $article=db('article')->where($where)->paginate(5);
        $page = $article->render();

        $article=$article->toArray();
         $data=$article['data'];
        foreach ($data as &$v) {
          $v['title']=preg_replace("/($q)/i", "<span style='color:red'>$q</span>", $v['title']);
          $v['description']=preg_replace("/($q)/i", "<span style='color:red'>$q</span>", $v['description']);
        }
        $this->assign('list',$data);
        $this->assign('page', $page);
        $name=$q;
        $this->assign('name', $name);
        return $this->fetch('Column/index');


    }

   

}
