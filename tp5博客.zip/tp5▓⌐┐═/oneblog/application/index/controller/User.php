<?php
namespace app\index\controller;
use \think\Controller;
use \think\Request;
use \think\Validate;
use app\index\model\Comment as Commentm;


class User extends Common
{

   function index(){
      
       $message=db('message')->where(['userid'=>input('userid')])->paginate(10);
       $user=db('User')->where(['id'=>input('userid')])->find();
       

        // 获取分页显示
        $page = $message->render();
        $this->assign('user',$user);
        $this->assign('list',$message);
        $this->assign('page', $page);
        return $this->fetch();
   }

   function getusercomment(){

       // $comment=db('comment')->where(['userid'=>input('userid')])->paginate(10);


      
        $comment = new Commentm();
        // 查询数据集
        $comment=$comment->where('userid', input('userid'))->with('article')->order('id desc')->paginate(10);

        // 获取分页显示
        $page = $comment->render();
        $this->assign('list',$comment);
        $this->assign('page', $page);
        $this->assign('userid',input('userid'));
        
        return $this->fetch();

   }

   // 更多留言板


   // 添加评论
   function add(){
       
     $data = [
                'comment'  => input('post.comment'),
                'articleid'  => input('post.articleid'),
                'userid'  => input('post.userid')
            ];
       $id=db('comment')->insert($data);
       if ($id) {
           $this->redirect('Index/index');
       }
   }

  function register(){

    if (Request::instance()->isPost()) {

         $rule = [
          'username'  => 'require|unique:user',
          'userpassword'  => 'require',
      ];

      $msg = [
          'username.require' => '用户名不能为空',
          'username.unique' => '用户名已经存在',
          'userpassword.require' => '密码必须',
      ];

            $validate = new Validate($rule,$msg);
        $data = [
                'username'  => input('post.username'),
                'userpassword'  => input('post.userpassword')
            ];

      if (!$validate->check($data)) {
          $this->error($validate->getError());
      }else{
        $id=db('user')->insert($data);
        if ($id) {
           session('userid', $id);
           session('username', $data['username']);
           $this->redirect('Index/index');
        }else{
          $this->error('添加失败');
        }
       
      }

    }
        return $this->fetch();


  }


   function login(){


      if (Request::instance()->isPost()) {

         $rule = [
          'username'  => 'require',
          'userpassword'  => 'require',
      ];

      $msg = [
          'username.require' => '用户名不能为空',
          'username.unique' => '用户名已经存在',
          'userpassword.require' => '密码必须',
      ];

            $validate = new Validate($rule,$msg);
        $data = [
                'username'  => input('post.username'),
                'userpassword'  => input('post.userpassword')
            ];

      if (!$validate->check($data)) {
          $this->error($validate->getError());
      }else{
        $id=db('user')->where($data)->find();
        if ($id) {
           session('userid', $id['id']);
           session('username', $id['username']);
          $this->redirect('Index/index');
           //$this->success('登录成功');
        }else{
          $this->error('登录失败');
        }
       
      }

    }
        return $this->fetch();
  }
  
  
  function outlogin(){
     session(null);
     $this->redirect('Index/index');
  }




}


