<?php
namespace app\index\model;

use think\Model;

class Comment extends Model 
{
	public $name='comment';
    public function article()
    {
        return $this->belongsTo('article','articleid','id');
    }
    

    public function user()
    {
        return $this->belongsTo('user','userid','id');
    }
    

}