<?php
namespace app\index\model;

use think\Model;

class User extends Model 
{
	public $name='user';
    public function comment()
    {
         return $this->hasMany('comment','userid','id');
    }


    public function message()
    {
         return $this->hasMany('message','userid','id');
    }


    
    
}