<?php
namespace app\index\model;

use think\Model;

class Article extends Model 
{
	public $name='article';
    public function comment()
    {
         return $this->hasMany('comment','articleid','id');
    }

     public function column()
    {
        return $this->belongsTo('column','columnid','id');
    }
    
}