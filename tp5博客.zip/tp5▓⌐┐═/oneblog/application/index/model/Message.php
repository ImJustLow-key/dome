<?php
namespace app\index\model;

use think\Model;

class Message extends Model 
{
	public $name='message';
    public function user()
    {
        return $this->belongsTo('user','userid','id');
    }
    
}