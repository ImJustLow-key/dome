<?php
namespace app\index\model;

use think\Model;

class Column extends Model 
{
	public $name='column';
    public function article()
    {
         return $this->hasMany('article','columnid','id');
    }
    
}