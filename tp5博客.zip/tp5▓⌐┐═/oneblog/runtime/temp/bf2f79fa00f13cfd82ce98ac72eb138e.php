<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:70:"D:\xampp\htdocs\oneblog\public/../application/admin\view\link\add.html";i:1518600767;s:56:"D:\xampp\htdocs\oneblog\application\admin\view\base.html";i:1519577322;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>『童老师ThinkPHP』后台管理</title>
    <link rel="stylesheet" type="text/css" href="/oneblog/public/static/css/common.css"/>
    <link rel="stylesheet" type="text/css" href="/oneblog/public/static/css/main.css"/>
    <script type="text/javascript" src="/oneblog/public/static/js/libs/modernizr.min.js"></script>


    <link href="/oneblog/public/static/ueditor/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
    <script type="text/javascript" src="/oneblog/public/static/ueditor/third-party/jquery.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="/oneblog/public/static/ueditor/umeditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/oneblog/public/static/ueditor/umeditor.min.js"></script>
    <script type="text/javascript" src="/oneblog/public/static/ueditor/lang/zh-cn/zh-cn.js"></script>


</head>
<body>
<div class="topbar-wrap white">
    <div class="topbar-inner clearfix">
        <div class="topbar-logo-wrap clearfix">
            <h1 class="topbar-logo none"><a href="index.html" class="navbar-brand">后台管理</a></h1>
            <ul class="navbar-list clearfix">
                <li><a class="on" href="index.html">首页</a></li>
                <li><a href="<?php echo url('index/Index/index'); ?>" target="_blank">网站首页</a></li>
            </ul>
        </div>
        <div class="top-info-wrap">
            <ul class="top-info-list clearfix">
                <li><a href="#">管理员</a></li>
                <li><a href="#">修改密码</a></li>
                <li><a href="<?php echo url('Admin/outlogin'); ?>">退出</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>常用操作</a>
                    <ul class="sub-menu">
                        <li><a href="<?php echo url('Column/index'); ?>"><i class="icon-font">&#xe006;</i>栏目管理</a></li>
                        <li><a href="<?php echo url('Article/index'); ?>"><i class="icon-font">&#xe005;</i>博文管理</a></li>
                        <li><a href="<?php echo url('label/index'); ?>"><i class="icon-font">&#xe012;</i>标签管理</a></li>
                        <li><a href="<?php echo url('Message/index'); ?>"><i class="icon-font">&#xe004;</i>留言管理</a></li>
                        <li><a href="<?php echo url('Comment/index'); ?>"><i class="icon-font">&#xe012;</i>评论管理</a></li>
                        <li><a href="<?php echo url('link/index'); ?>"><i class="icon-font">&#xe052;</i>友情链接</a></li>

                         <li><a href="<?php echo url('Admin/index'); ?>"><i class="icon-font">&#xe052;</i>管理员管理</a></li>

                    </ul>
                </li>
               
            </ul>
        </div>
    </div>
    <!--/sidebar-->
    
 <!--/sidebar-->
    <div class="main-wrap">

        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="/jscss/admin/design/">首页</a><span class="crumb-step">&gt;</span><a class="crumb-name" href="/jscss/admin/design/">链接管理</a><span class="crumb-step">&gt;</span><span>新增链接</span></div>
        </div>
        <div class="result-wrap">
            <div class="result-content">
                <form action="" method="post" id="myform" name="myform">
                    <table class="insert-tab" width="100%">
                        <tbody>
                            <tr>
                                <th><i class="require-red">*</i>链接名称：</th>
                                <td>
                                    <input class="common-text required" id="title" name="name" size="50" value="" type="text">
                                </td>
                            </tr>
                            <tr>
                                <th><i class="require-red">*</i>链接地址：</th>
                                <td>
                                    <input class="common-text required" id="url" name="url" size="50" value="" type="text">
                                </td>
                            </tr>
                            <tr>
                                <th><i class="require-red">*</i>链接描述：</th>
                                <td>
                                    <textarea style="width:400px; height:100px;" name="description"></textarea>
                                </td>
                            </tr>
                            
                            <tr>
                                <th></th>
                                <td>
                                    <input class="btn btn-primary btn6 mr10" value="提交" type="submit">
                                    <input class="btn btn6" onclick="history.go(-1)" value="返回" type="button">
                                </td>
                            </tr>
                        </tbody></table>
                </form>
            </div>
        </div>

    </div>
    <!--/main-->



    <!--/main-->
</div>

<script type="text/javascript">

    var um = UM.getEditor('content');
   

    //上传图片
    $('#pic').change(function(event) {
        var formData = new FormData();
        formData.append("file", $(this).get(0).files[0]);
        $.ajax({
            url:'/oneblog/public/admin/Article/upload',
            type:'POST',
            data:formData,
            cache: false,
            contentType: false,    //不可缺
            processData: false,    //不可缺
            success:function(data){
                //console.log(data);
                var path='/oneblog/public/static/uploads/'+data;
                $('.picimgs').attr('src',path); 
                $("#articeimg").val(data);
             //  $('#pic').val(data); 
            }
        });
    });



</script>


</body>
</html>