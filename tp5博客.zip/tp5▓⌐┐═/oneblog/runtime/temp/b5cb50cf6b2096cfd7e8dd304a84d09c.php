<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:63:"D:\xampp\htdocs\oneblog/application/index\view\index\index.html";i:1519627186;s:63:"D:\xampp\htdocs\oneblog\application\index\view\public\head.html";i:1519063829;s:65:"D:\xampp\htdocs\oneblog\application\index\view\public\footer.html";i:1519627060;}*/ ?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-param" content="_csrf">
    <meta name="csrf-token" content="Gj6DpYM7qX5_hsj-P6ayfKdKcLKnL3CcGK8FaACnMOdvRsXv6F2bHCj-qcZW9tUtzTs7gZ9uNd1e7X8ZM5R3sw==">
<title></title>
<meta name="keywords" content="">
<meta name="description" content="">
<link href="/oneblog/static/index/css/bootstrap.css" rel="stylesheet">


<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon">
<link href="/oneblog/static/index/css/bootstrap-theme.css" rel="stylesheet">
<link href="/oneblog/static/index/css/font-awesome.min.css" rel="stylesheet">
<link href="/oneblog/static/index/css/nanoscroller.css" rel="stylesheet">
<link href="/oneblog/static/index/css/style.css" rel="stylesheet">
<link href="/oneblog/static/index/css/site.css" rel="stylesheet">

</head>
<body>
<div class="wrap">
  
  <!-- 头部 --> 
    <nav id="w3" class="navbar-inverse navbar-fixed-top navbar"><div class="container"><div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#w3-collapse">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span></button><a class="navbar-brand" href="/"></a></div><div id="w3-collapse" class="collapse navbar-collapse">

<ul id="w4" class="navbar-nav navbar-left nav"><li><a href="<?php echo url('Index/index'); ?>">首页</a></li>


<?php if(is_array($column) || $column instanceof \think\Collection || $column instanceof \think\Paginator): $i = 0; $__LIST__ = $column;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
  <li ><a href="<?php echo url('Column/index',['id'=>$vo['id']]); ?>"><?php echo $vo['name']; ?></a></li>
<?php endforeach; endif; else: echo "" ;endif; ?>


<!-- <li class="active"><a href="/tutorial">教程</a></li> -->


</ul>

<form class="navbar-form visible-lg-inline-block" action="<?php echo url('Article/search'); ?>" method="get"><div class="input-group"><input type="text" class="form-control" name="q" placeholder="全站搜索"><span class="input-group-btn"><button type="submit" class="btn btn-default">搜索</button></span></div></form>


<?php if(\think\Session::get('userid') != null): ?>
             
             <ul id="w5" class="navbar-nav navbar-right nav">

		<li><a href="<?php echo url('User/index',['userid'=>\think\Session::get('userid')]); ?>"><?php echo \think\Session::get('username'); ?></a></li>
	    <li><a href="<?php echo url('User/outlogin'); ?>" >退出</a></li>

	</ul>


           <?php else: ?>
	<ul id="w5" class="navbar-nav navbar-right nav">

		<li><a href="<?php echo url('User/register'); ?>">注册</a></li>
	    <li><a href="<?php echo url('User/login'); ?>" >登录</a></li>

	</ul>
<?php endif; ?>


</div></div>
</nav>   



 

<div class="container">
     
<div class="row">
    <div class="col-lg-9">
     

        <ul id="w1" class="media-list">


<ul class="excerpt thumb">
  <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
      <li style="padding: 10px 0;">
      <a href="<?php echo url('Article/index',['id'=>$vo['id']]); ?>" class="pic">

          <img src="


                            <?php if(($vo['pic'] == '')): ?> /oneblog/public/static/images/imgs.jpg
                            <?php else: ?> /oneblog/public/static/uploads/<?php echo $vo['pic']; endif; ?>
            " width="100" height="80">

       </a>      <h2 class="excerpt-tit" style="margin-bottom: 4px;">
        <a href="<?php echo url('Article/index',['id'=>$vo['id']]); ?>" style="font-size: 15px;"><?php echo $vo['title']; ?></a>
      </h2>
      <p class="excerpt-desc"><?php echo $vo['description']; ?>...</p>
      <div class="times"> <div style="width: 50px;height: 10px;"></div></div>
    </li>

    <?php endforeach; endif; else: echo "" ;endif; ?>
  </ul>





</ul>   
 </div>
   
  <!-- 右部  -->
<div class="col-lg-3 col-md-3">
    <div class="panel panel-default">
            <div class="panel-heading">
            <h2 class="panel-title" style="color: #fff;"> 大家正在说 </h2>
                <span class="pull-right"><a class="btn btn-xs" href="<?php echo url('Message/allmessage'); ?>" style="color: #fff;">更多&raquo;</a></span>
            </div>
            <div class="panel-body">
                
<form id="messagefm" action="<?php echo url('Message/add'); ?>" method="post">

<div class="form-group input-group field-feed-content required">
<textarea id="feed-content" class="form-control messageadd" name="content" placeholder="我想说..." aria-required="true"></textarea>

<span class="input-group-btn"><button type="button" class="btn btn-success btnmessage">发布</button></span>
</div>
</form>

<div class="feed"><div class="nano">
<ul id="w1" class="media-list nano-content message">
<!-- <li class="media" data-key="29257"><div class="media-body"><div class="media-content"><a href="/user/luobt17" rel="author">菜鸟鼻涕</a>: two hour later, i willhey</div><div class="media-action"><span class="time">2018-02-13 13:18</span></div></div></li> -->




</ul></div></div>
            </div>
        </div>
</div>





</div>
    </div>
    <a class="back-to-top btn btn-default"><span class="fa fa-arrow-up"></span></a>
</div>

<!-- 尾部 -->


 <footer class="footer">
    <div class="container visible-lg-block">
        <div class="row">
           <!--  <div class="col-lg-2">
                <h2>友情链接</h2>
                <ul>
                    <li><a href="/about">Yii 的简介</a></li>
                    <li><a href="/news">Yii 的动态</a></li>
                    
                </ul>
            </div> -->
           
           <?php echo $template; ?>
     
           
        </div>
    </div>
   
</footer> 



<div id="w7" class="fade modal" role="dialog" tabindex="-1">
<div class="modal-dialog ">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

</div>
<div class="modal-body">

</div>

</div>
</div>
</div>

<script src="/oneblog/static/index/js/jquery.js"></script>

<script src="/oneblog/static/index/js/highlight.pack.js"></script>
<script src="/oneblog/static/index/js/emojify.min.js"></script>
<script src="/oneblog/static/index/js/yii.js"></script>
<script src="/oneblog/static/index/js/jquery.nanoscroller.min.js"></script>
<script src="/oneblog/static/index/js/main.js"></script>
<script src="/oneblog/static/index/js/bootstrap.js"></script>


<script type="text/javascript">jQuery(function ($) {
jQuery('#w7').modal({"show":false});
});

  

  
  
  function getmessage() {
     
      var url='/oneblog/public/index/Message/getmessage';
     $.get(url,function(data,status){

      var temuban='';
      var msg=data.msg.data;
      
      for (var i = 0; i<msg.length; i++) {
        temuban += '<li class="media" ><div class="media-body"><div class="media-content"><a href="'+ '/oneblog/public/index/User/index/userid/' +msg[i].userid+'">'+msg[i].user.username;
        temuban += '</a>:'+msg[i].content;
        temuban += '</div><div class="media-action"></div></div></li>';
      }
      $('.message').html(temuban);
    });
  }

  setInterval("getmessage()",100);



  $(".btnmessage").click(function(){
    
      $.ajax({  
                type: "POST",  
                url:"<?php echo url('Message/add'); ?>",  
                data:$('#messagefm').serialize(),// 序列化表单值  
                async: false,  
                error: function(request) {  
                    alert("Connection error");  
                },  
                success: function(data) { 
                  $(".messageadd").val(''); 
                   //console.log(data.code);
                   if (data.code == 0) {
                     alert('请先登录');
                   }
                }  
            });  

});


</script>


</body>
</html>
