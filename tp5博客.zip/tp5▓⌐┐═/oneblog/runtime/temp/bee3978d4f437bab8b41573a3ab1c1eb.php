<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:81:"D:\xampp\htdocs\oneblog\public/../application/index\view\user\getusercomment.html";i:1519097679;s:63:"D:\xampp\htdocs\oneblog\application\index\view\public\head.html";i:1519629316;s:64:"D:\xampp\htdocs\oneblog\application\index\view\public\right.html";i:1519040436;s:65:"D:\xampp\htdocs\oneblog\application\index\view\public\footer.html";i:1519627060;}*/ ?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-param" content="_csrf">
    <meta name="csrf-token" content="Vc28GdIMw7VNnisCWqWtOImbZZKc3EuG3AHkHNKCXx4StN9Ds2Wv7xzkeVdt4_dP2O8Q5_69J9O3aI8pvNctaA==">
<title></title>

<!-- <meta name="keywords" content="sdfsdf">
<meta name="description" content="sdfsdfs"> -->

<link href="/oneblog/public/static/index/css/bootstrap.css" rel="stylesheet">
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon">
<link href="/oneblog/public/static/index/css/bootstrap-theme.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/font-awesome.min.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/nanoscroller.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/style.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/site.css" rel="stylesheet">

</head>
<body>
<div class="wrap">
  
  <!-- 头部 --> 
   <nav id="w3" class="navbar-inverse navbar-fixed-top navbar"><div class="container"><div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#w3-collapse">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span></button><a class="navbar-brand" href="/"></a></div><div id="w3-collapse" class="collapse navbar-collapse">

<ul id="w4" class="navbar-nav navbar-left nav"><li><a href="<?php echo url('Index/index'); ?>">首页</a></li>


<?php if(is_array($column) || $column instanceof \think\Collection || $column instanceof \think\Paginator): $i = 0; $__LIST__ = $column;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
 <!--  <li ><a href="<?php echo url('Column/index',['id'=>$vo['id']]); ?>"><?php echo $vo['name']; ?></a></li> -->


<?php endforeach; endif; else: echo "" ;endif; ?>


<!-- <li class="active"><a href="/tutorial">教程</a></li> -->


</ul>

<form class="navbar-form visible-lg-inline-block" action="<?php echo url('Article/search'); ?>" method="get"><div class="input-group"><input type="text" class="form-control" name="q" placeholder="全站搜索"><span class="input-group-btn"><button type="submit" class="btn btn-default">搜索</button></span></div></form>


<?php if(\think\Session::get('userid') != null): ?>
             
             <ul id="w5" class="navbar-nav navbar-right nav">

		<li><a href="<?php echo url('User/index',['userid'=>\think\Session::get('userid')]); ?>"><?php echo \think\Session::get('username'); ?></a></li>
	    <li><a href="<?php echo url('User/outlogin'); ?>" >退出</a></li>

	</ul>


           <?php else: ?>
	<ul id="w5" class="navbar-nav navbar-right nav">

		<li><a href="<?php echo url('User/register'); ?>">注册</a></li>
	    <li><a href="<?php echo url('User/login'); ?>" >登录</a></li>

	</ul>
<?php endif; ?>


</div></div>
</nav>   



 


 <div class="container">
            
<div class="row">
     <div class="col-lg-9">
        
<ul id="w0" class="nav nav-tabs nav-user"><li ><a href="<?php echo url('User/index',['userid'=>$userid]); ?>">留言板</a></li>
<li class="active"><a href="<?php echo url('User/getusercomment',['userid'=>$userid]); ?>">文章评论</a></li>
</ul>
<ul id="w1" class="media-list">

<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

  
<li class="media" >

   

   <div class="media-body"><div class="media-heading"><a href="<?php echo url('Article/index',['id'=>$vo['article']['id']]); ?>" rel="author"><?php echo $vo['article']['title']; ?></a> </div><div class="media-content"><?php echo $vo['comment']; ?></div><div class="media-action"></div></div>

 </li>

<?php endforeach; endif; else: echo "" ;endif; ?>





<?php echo $page; ?>


</ul>    </div>



 


     <!-- 右部  -->

   <div class="col-lg-3">
        
     
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2 class="panel-title" style="color: #fff;">最新文章</h2>
            </div>
            <div class="panel-body">
                <ul class="post-list">

                                      
                                   
                <?php if(is_array($rightarticle) || $rightarticle instanceof \think\Collection || $rightarticle instanceof \think\Paginator): $i = 0; $__LIST__ = $rightarticle;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                 
                    <li> <a href="<?php echo url('Article/index',['id'=>$vo['id']]); ?>"><?php echo $vo['title']; ?></a></li>
                <?php endforeach; endif; else: echo "" ;endif; ?>      
                                       
                </ul>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading">
                <h2 class="panel-title" style="color: #fff;">文章分类</h2>
            </div>
            <div class="panel-body">
                

                <?php if(is_array($column) || $column instanceof \think\Collection || $column instanceof \think\Paginator): $i = 0; $__LIST__ = $column;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                  <a class="tag" href="<?php echo url('Column/index',['id'=>$vo['id']]); ?>" ><?php echo $vo['name']; ?></a>
                <?php endforeach; endif; else: echo "" ;endif; ?>


            </div>
        </div>

    
    </div> 



</div>
    </div>
    <a class="back-to-top btn btn-default"><span class="fa fa-arrow-up"></span></a>
</div>




<!-- 尾部 -->


 <footer class="footer">
    <div class="container visible-lg-block">
        <div class="row">
           <!--  <div class="col-lg-2">
                <h2>友情链接</h2>
                <ul>
                    <li><a href="/about">Yii 的简介</a></li>
                    <li><a href="/news">Yii 的动态</a></li>
                    
                </ul>
            </div> -->
           
           <?php echo $template; ?>
     
           
        </div>
    </div>
   
</footer> 



<div id="w7" class="fade modal" role="dialog" tabindex="-1">
<div class="modal-dialog ">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

</div>
<div class="modal-body">

</div>

</div>
</div>
</div>

<div style="position: fixed;left: 50%;top: 30%;width: 200px;margin-left: -100px;display: none;" class="loading">
     <img src="/oneblog/public/static/img/loading.gif" width="200">
</div>

<script src="/oneblog/public/static/index/js/jquery.js"></script>

<script src="/oneblog/public/static/index/js/highlight.pack.js"></script>
<script src="/oneblog/public/static/index/js/emojify.min.js"></script>
<script src="/oneblog/public/static/index/js/yii.js"></script>
<script src="/oneblog/public/static/index/js/jquery.nanoscroller.min.js"></script>
<script src="/oneblog/public/static/index/js/main.js"></script>
<script src="/oneblog/public/static/index/js/bootstrap.js"></script>
<script type="text/javascript">


jQuery(function ($) {
hljs.initHighlightingOnLoad();
jQuery('#w6').modal({"show":false});
});
 
 

 
</script>
</body>
</html>
