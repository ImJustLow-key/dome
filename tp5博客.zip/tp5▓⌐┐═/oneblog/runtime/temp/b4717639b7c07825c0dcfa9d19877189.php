<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:75:"D:\xampp\htdocs\oneblog\public/../application/index\view\article\index.html";i:1519097464;s:63:"D:\xampp\htdocs\oneblog\application\index\view\public\head.html";i:1519629316;s:64:"D:\xampp\htdocs\oneblog\application\index\view\public\right.html";i:1519040436;s:65:"D:\xampp\htdocs\oneblog\application\index\view\public\footer.html";i:1519627060;}*/ ?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-param" content="_csrf">
    <meta name="csrf-token" content="Vc28GdIMw7VNnisCWqWtOImbZZKc3EuG3AHkHNKCXx4StN9Ds2Wv7xzkeVdt4_dP2O8Q5_69J9O3aI8pvNctaA==">
<title><?php echo $article['title']; ?></title>

<meta name="keywords" content="<?php echo $article['title']; ?>">
<meta name="description" content="<?php echo $article['description']; ?>">

<link href="/oneblog/public/static/index/css/bootstrap.css" rel="stylesheet">
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon">
<link href="/oneblog/public/static/index/css/bootstrap-theme.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/font-awesome.min.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/nanoscroller.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/style.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/site.css" rel="stylesheet">

</head>
<body>
<div class="wrap">
  
  <!-- 头部 --> 
   <nav id="w3" class="navbar-inverse navbar-fixed-top navbar"><div class="container"><div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#w3-collapse">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span></button><a class="navbar-brand" href="/"></a></div><div id="w3-collapse" class="collapse navbar-collapse">

<ul id="w4" class="navbar-nav navbar-left nav"><li><a href="<?php echo url('Index/index'); ?>">首页</a></li>


<?php if(is_array($column) || $column instanceof \think\Collection || $column instanceof \think\Paginator): $i = 0; $__LIST__ = $column;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
 <!--  <li ><a href="<?php echo url('Column/index',['id'=>$vo['id']]); ?>"><?php echo $vo['name']; ?></a></li> -->


<?php endforeach; endif; else: echo "" ;endif; ?>


<!-- <li class="active"><a href="/tutorial">教程</a></li> -->


</ul>

<form class="navbar-form visible-lg-inline-block" action="<?php echo url('Article/search'); ?>" method="get"><div class="input-group"><input type="text" class="form-control" name="q" placeholder="全站搜索"><span class="input-group-btn"><button type="submit" class="btn btn-default">搜索</button></span></div></form>


<?php if(\think\Session::get('userid') != null): ?>
             
             <ul id="w5" class="navbar-nav navbar-right nav">

		<li><a href="<?php echo url('User/index',['userid'=>\think\Session::get('userid')]); ?>"><?php echo \think\Session::get('username'); ?></a></li>
	    <li><a href="<?php echo url('User/outlogin'); ?>" >退出</a></li>

	</ul>


           <?php else: ?>
	<ul id="w5" class="navbar-nav navbar-right nav">

		<li><a href="<?php echo url('User/register'); ?>">注册</a></li>
	    <li><a href="<?php echo url('User/login'); ?>" >登录</a></li>

	</ul>
<?php endif; ?>


</div></div>
</nav>   



 


 <div class="container">
        <ul class="breadcrumb"><li><a href="/">首页</a></li>
<li><a href="/tutorial"><?php echo $article['column']['name']; ?></a></li>
<li class="active"><?php echo $article['title']; ?></li>
</ul>        
<div class="row">
    <div class="col-lg-9">
        <div class="page-header">
            <h1>
                 <?php echo $article['title']; ?>
            </h1>
        </div>

        <div class="action">
           
           <!--  <span> 2018-02-05 22:00:39</span> -->
            
        </div>

    

    

    <!-- 内容 -->
   

    <?php echo $article['content']; ?>
        
        <div class="bdsharebuttonbox">
            <a href="#" class="bds_more" data-cmd="more">分享到：</a>
            <a title="分享到QQ空间" href="#" class="bds_qzone" data-cmd="qzone">QQ空间</a>
            <a title="分享到新浪微博" href="#" class="bds_tsina" data-cmd="tsina">新浪微博</a>
            <a title="分享到腾讯微博" href="#" class="bds_tqq" data-cmd="tqq">腾讯微博</a>
            <a title="分享到人人网" href="#" class="bds_renren" data-cmd="renren">人人网</a>
            <a title="分享到微信" href="#" class="bds_weixin" data-cmd="weixin">微信</a>
            <a title="分享到QQ好友" href="#" class="bds_sqq" data-cmd="sqq">QQ好友</a>
        </div>
        <script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"24"},"share":{"bdSize":16}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
       


       <div id="comment">
    <div class="page-header">
        <h2>发表评论</h2>
    </div>
            
            
            <?php if(\think\Session::get('userid') != null): ?>
               <div class="well danger">
               <form action="<?php echo url('Comment/add'); ?>" method="post" id="fm">
                 <textarea  name='comment' style="width: 80%;height: 100px;"></textarea>
                  <div class="form-group">
                    <button type="button" class="btn btn-primary" name="login-button" id="btncomment" style="margin: 10px 0 -30px 0;">发表评论</button>
                  </div>

                  <input type="hidden" name="userid" value="<?php echo \think\Session::get('userid'); ?>">
                  <input type="hidden" name="articleid" value="<?php echo $article['id']; ?>">

                </form>
 
            </div>

           <?php else: ?>
               <div class="well danger">您需要登录后才可以评论。<a href="<?php echo url('User/login'); ?>">登录</a> | <a href="<?php echo url('User/register'); ?>">立即注册</a></div>
            <?php endif; ?>

       

    </div>



        <div id="comments">
            <div class="page-header">
                <h2>评论</h2>
                <ul id="w0" class="nav nav-tabs nav-sub"><li class="active"></li>
<li></li></ul>            </div>

            <ul id="w1" class="media-list">


<!-- 
<li class="media" data-key="6939">
<div class="media-body">
    <div class="media-heading">
        <a href="/user/44032" rel="author">用户名</a> 评论于 2018-02-06 12:02 
    </div>
    <div class="media-content">
       内容
   </div>
</div>
</li> -->




</ul>        </div>
        

    </div>

 


     <!-- 右部  -->

   <div class="col-lg-3">
        
     
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2 class="panel-title" style="color: #fff;">最新文章</h2>
            </div>
            <div class="panel-body">
                <ul class="post-list">

                                      
                                   
                <?php if(is_array($rightarticle) || $rightarticle instanceof \think\Collection || $rightarticle instanceof \think\Paginator): $i = 0; $__LIST__ = $rightarticle;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                 
                    <li> <a href="<?php echo url('Article/index',['id'=>$vo['id']]); ?>"><?php echo $vo['title']; ?></a></li>
                <?php endforeach; endif; else: echo "" ;endif; ?>      
                                       
                </ul>
            </div>
        </div>

        <div class="panel panel-default">
            <div class="panel-heading">
                <h2 class="panel-title" style="color: #fff;">文章分类</h2>
            </div>
            <div class="panel-body">
                

                <?php if(is_array($column) || $column instanceof \think\Collection || $column instanceof \think\Paginator): $i = 0; $__LIST__ = $column;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                  <a class="tag" href="<?php echo url('Column/index',['id'=>$vo['id']]); ?>" ><?php echo $vo['name']; ?></a>
                <?php endforeach; endif; else: echo "" ;endif; ?>


            </div>
        </div>

    
    </div> 



</div>
    </div>
    <a class="back-to-top btn btn-default"><span class="fa fa-arrow-up"></span></a>
</div>




<!-- 尾部 -->


 <footer class="footer">
    <div class="container visible-lg-block">
        <div class="row">
           <!--  <div class="col-lg-2">
                <h2>友情链接</h2>
                <ul>
                    <li><a href="/about">Yii 的简介</a></li>
                    <li><a href="/news">Yii 的动态</a></li>
                    
                </ul>
            </div> -->
           
           <?php echo $template; ?>
     
           
        </div>
    </div>
   
</footer> 



<div id="w7" class="fade modal" role="dialog" tabindex="-1">
<div class="modal-dialog ">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

</div>
<div class="modal-body">

</div>

</div>
</div>
</div>

<div style="position: fixed;left: 50%;top: 30%;width: 200px;margin-left: -100px;display: none;" class="loading">
     <img src="/oneblog/public/static/img/loading.gif" width="200">
</div>

<script src="/oneblog/public/static/index/js/jquery.js"></script>

<script src="/oneblog/public/static/index/js/highlight.pack.js"></script>
<script src="/oneblog/public/static/index/js/emojify.min.js"></script>
<script src="/oneblog/public/static/index/js/yii.js"></script>
<script src="/oneblog/public/static/index/js/jquery.nanoscroller.min.js"></script>
<script src="/oneblog/public/static/index/js/main.js"></script>
<script src="/oneblog/public/static/index/js/bootstrap.js"></script>
<script type="text/javascript">


jQuery(function ($) {
hljs.initHighlightingOnLoad();
jQuery('#w6').modal({"show":false});
});
 
 
 $("#btncomment").click(function(){
      $.ajax({  
                type: "POST",  
                url:"<?php echo url('Comment/add'); ?>",  
                data:$('#fm').serialize(),// 序列化表单值  
                async: false,  
                error: function(request) {  
                    alert("Connection error");  
                },  
                success: function(data) {  
                   // window.location.href="跳转页面"  
                   
                   if (data.code==1) {
                      // alert(data.msg);
                      location.reload();
                   }else{
                      alert(data.msg);
                   }
                }  
            });  

});
function getcomment(page){
  //var url='<?php echo url("Comment/getcomment"); ?>'+'/articleid/<?php echo $article["id"]; ?>'+'/page/'+page;
  var url='/oneblog/public/index/comment/getcomment/articleid/<?php echo $article["id"]; ?>/page/'+page;
  $(".loading").show(); // 显示
   $.get(url,function(data,status){
    var temuban='';
    var msg=data.msg;
    for (var i = 0; i<msg.length; i++) {
      temuban += '<li class="media" ><div class="media-body"><div class="media-heading"><a href="'+ '/oneblog/public/index/User/index/userid/'+ msg[i].user.id +'" rel="author">'+msg[i].user.username;
      temuban += '</a></div><div class="media-content">'+msg[i].comment;
      temuban += '</div></div></li>';
    }

  $('#w1').append(temuban);
   stop=true; 
   $(".loading").hide();
  });
}
getcomment(1);
var stop=true;//触发开关，防止多次调用事件 
var page=1;
$(window).scroll( function(event){
//当内容滚动到底部时加载新的内容 100当距离最底部100个像素时开始加载. 
if ($(this).scrollTop() + $(window).height() + 10 >= $(document).height() && $(this).scrollTop() > 10) {
        if(stop==true){
            stop=false;
            page=page+1;//当前要加载的页码 
            getcomment(page);
        }
} 
});


 
</script>
</body>
</html>
