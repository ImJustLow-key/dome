<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:72:"D:\xampp\htdocs\oneblog\public/../application/index\view\user\login.html";i:1519038533;s:63:"D:\xampp\htdocs\oneblog\application\index\view\public\head.html";i:1519629316;s:65:"D:\xampp\htdocs\oneblog\application\index\view\public\footer.html";i:1519627060;}*/ ?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-param" content="_csrf">
    <meta name="csrf-token" content="Vc28GdIMw7VNnisCWqWtOImbZZKc3EuG3AHkHNKCXx4StN9Ds2Wv7xzkeVdt4_dP2O8Q5_69J9O3aI8pvNctaA==">
<title>登录</title>


<link href="/oneblog/public/static/index/css/bootstrap.css" rel="stylesheet">
<link type="image/x-icon" href="/favicon.ico" rel="shortcut icon">
<link href="/oneblog/public/static/index/css/bootstrap-theme.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/font-awesome.min.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/nanoscroller.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/style.css" rel="stylesheet">
<link href="/oneblog/public/static/index/css/site.css" rel="stylesheet">

</head>
<body>
<div class="wrap">
  
  <!-- 头部 --> 
   <nav id="w3" class="navbar-inverse navbar-fixed-top navbar"><div class="container"><div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#w3-collapse">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span></button><a class="navbar-brand" href="/"></a></div><div id="w3-collapse" class="collapse navbar-collapse">

<ul id="w4" class="navbar-nav navbar-left nav"><li><a href="<?php echo url('Index/index'); ?>">首页</a></li>


<?php if(is_array($column) || $column instanceof \think\Collection || $column instanceof \think\Paginator): $i = 0; $__LIST__ = $column;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
 <!--  <li ><a href="<?php echo url('Column/index',['id'=>$vo['id']]); ?>"><?php echo $vo['name']; ?></a></li> -->


<?php endforeach; endif; else: echo "" ;endif; ?>


<!-- <li class="active"><a href="/tutorial">教程</a></li> -->


</ul>

<form class="navbar-form visible-lg-inline-block" action="<?php echo url('Article/search'); ?>" method="get"><div class="input-group"><input type="text" class="form-control" name="q" placeholder="全站搜索"><span class="input-group-btn"><button type="submit" class="btn btn-default">搜索</button></span></div></form>


<?php if(\think\Session::get('userid') != null): ?>
             
             <ul id="w5" class="navbar-nav navbar-right nav">

		<li><a href="<?php echo url('User/index',['userid'=>\think\Session::get('userid')]); ?>"><?php echo \think\Session::get('username'); ?></a></li>
	    <li><a href="<?php echo url('User/outlogin'); ?>" >退出</a></li>

	</ul>


           <?php else: ?>
	<ul id="w5" class="navbar-nav navbar-right nav">

		<li><a href="<?php echo url('User/register'); ?>">注册</a></li>
	    <li><a href="<?php echo url('User/login'); ?>" >登录</a></li>

	</ul>
<?php endif; ?>


</div></div>
</nav>   



 



<div class="container">
        <ul class="breadcrumb"><li><a href="/">首页</a></li>
<li class="active">登录</li>
</ul>        <div class="site-login">
    <div class="page-header">
        <h1>登录</h1>
    </div>
    
    <div class="row">
        <div class="col-lg-5">
            <form id="login-form" action="" method="post">
<input type="hidden" name="_csrf" value="ASTW4soxwPZIhDgpyON3qmx4cP9Cub2KaJpZACQFUOdGXbW4q1isrBn-anz_pS3dPQwFiiDY0d8D8zI1SlAikQ==">                <div class="form-group field-loginform-username required">
<label class="control-label" for="loginform-username">用户名</label>
<input type="text" id="loginform-username" class="form-control" name="username" placeholder="用户名/电子邮箱" autocomplete="off" aria-required="true">

<div class="help-block"></div>
</div>                <div class="form-group field-loginform-password required">
<label class="control-label" for="loginform-password">密码</label>
<input type="password" id="loginform-password" class="form-control" name="userpassword" autocomplete="off" aria-required="true">

<div class="help-block"></div>
</div>                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="login-button">登录</button>                </div>
            </form>        </div>
     
    </div>
</div>
    </div>
    <a class="back-to-top btn btn-default"><span class="fa fa-arrow-up"></span></a>
</div>


<!-- 尾部 -->
 <footer class="footer">
    <div class="container visible-lg-block">
        <div class="row">
           <!--  <div class="col-lg-2">
                <h2>友情链接</h2>
                <ul>
                    <li><a href="/about">Yii 的简介</a></li>
                    <li><a href="/news">Yii 的动态</a></li>
                    
                </ul>
            </div> -->
           
           <?php echo $template; ?>
     
           
        </div>
    </div>
   
</footer> 

<div id="w5" class="fade modal" role="dialog" tabindex="-1">
<div class="modal-dialog ">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

</div>
<div class="modal-body">

</div>

</div>
</div>
</div>
<script src="/oneblog/public/static/index/js/jquery.js"></script>

<script src="/oneblog/public/static/index/js/highlight.pack.js"></script>
<script src="/oneblog/public/static/index/js/emojify.min.js"></script>
<script src="/oneblog/public/static/index/js/yii.js"></script>
<script src="/oneblog/public/static/index/js/jquery.nanoscroller.min.js"></script>
<script src="/oneblog/public/static/index/js/main.js"></script>
<script src="/oneblog/public/static/index/js/bootstrap.js"></script>

<script type="text/javascript">jQuery(function ($) {

jQuery('#w5').modal({"show":false});
});</script></body>
</html>
