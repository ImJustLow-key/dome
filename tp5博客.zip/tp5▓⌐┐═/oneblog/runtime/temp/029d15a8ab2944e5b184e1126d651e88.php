<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"D:\xampp\htdocs\oneblog\public/../application/admin\view\login\index.html";i:1519551787;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>后台登录</title>
    <link href="/oneblog/public/static/css/admin_login.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="admin_login_wrap">
    <h1>后台管理</h1>
    <div class="adming_login_border">
        <div class="admin_input">
            <form action="" method="post">
                <ul class="admin_items">
                    <li>
                        <label for="user">用户名：</label>
                        <input type="text" name="username" id="user" size="35" class="admin_input_style" />
                    </li>
                    <li>
                        <label for="pwd">密码：</label>
                        <input type="password" name="password" id="password" size="35" class="admin_input_style" />
                    </li>
              

                    <li>

                        <label for="pwd">验证码：</label>
                         <input type="text" name="captcha" id="verify" size="35" class="admin_input_style" />
                        <img src="<?php echo captcha_src(); ?>" alt="captcha" onclick="this.src=Math.random();" />

                    </li>


                    <li>
                        <input type="submit" tabindex="3" value="提交" class="btn btn-primary" />
                    </li>
                </ul>
            </form>
        </div>
    </div>
</div>
</body>
</html>