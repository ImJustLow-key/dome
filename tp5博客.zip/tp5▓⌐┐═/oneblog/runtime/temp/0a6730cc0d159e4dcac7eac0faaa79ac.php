<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:67:"D:\xampp\htdocs\a\public/../application/admin\view\admin\index.html";i:1519576483;s:50:"D:\xampp\htdocs\a\application\admin\view\base.html";i:1519577291;}*/ ?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>『童老师ThinkPHP』后台管理</title>
    <link rel="stylesheet" type="text/css" href="/a/public/static/css/common.css"/>
    <link rel="stylesheet" type="text/css" href="/a/public/static/css/main.css"/>
    <script type="text/javascript" src="/a/public/static/js/libs/modernizr.min.js"></script>


    <link href="/a/public/static/ueditor/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
    <script type="text/javascript" src="/a/public/static/ueditor/third-party/jquery.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="/a/public/static/ueditor/umeditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/a/public/static/ueditor/umeditor.min.js"></script>
    <script type="text/javascript" src="/a/public/static/ueditor/lang/zh-cn/zh-cn.js"></script>


</head>
<body>
<div class="topbar-wrap white">
    <div class="topbar-inner clearfix">
        <div class="topbar-logo-wrap clearfix">
            <h1 class="topbar-logo none"><a href="index.html" class="navbar-brand">后台管理</a></h1>
            <ul class="navbar-list clearfix">
                <li><a class="on" href="index.html">首页</a></li>
                <li><a href="<?php echo url('index/Index/index'); ?>" target="_blank">网站首页</a></li>
            </ul>
        </div>
        <div class="top-info-wrap">
            <ul class="top-info-list clearfix">
                <li><a href="#">管理员</a></li>
                <li><a href="#">修改密码</a></li>
                <li><a href="<?php echo url('Admin/outlogin'); ?>">退出</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>常用操作</a>
                    <ul class="sub-menu">
                        <li><a href="<?php echo url('Column/index'); ?>"><i class="icon-font">&#xe006;</i>栏目管理</a></li>
                        <li><a href="<?php echo url('Article/index'); ?>"><i class="icon-font">&#xe005;</i>博文管理</a></li>
                        <li><a href="<?php echo url('label/index'); ?>"><i class="icon-font">&#xe012;</i>标签管理</a></li>
                        <li><a href="<?php echo url('Message/index'); ?>"><i class="icon-font">&#xe004;</i>留言管理</a></li>
                        <li><a href="<?php echo url('Comment/index'); ?>"><i class="icon-font">&#xe012;</i>评论管理</a></li>
                        <li><a href="<?php echo url('link/index'); ?>"><i class="icon-font">&#xe052;</i>友情链接</a></li>

                         <li><a href="<?php echo url('Admin/index'); ?>"><i class="icon-font">&#xe052;</i>管理员管理</a></li>

                    </ul>
                </li>
               
            </ul>
        </div>
    </div>
    <!--/sidebar-->
    
 


  <!--/sidebar-->
    <div class="main-wrap">

        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="/jscss/admin">首页</a><span class="crumb-step">&gt;</span><span class="crumb-name">管理员管理</span></div>
        </div>
       
        <div class="result-wrap">
            <form name="myform" id="myform" action="/ykj/index.php/Admin/Admin/sort" method="post">
                <div class="result-title">
                    <div class="result-list">
                        <a href="<?php echo url('Admin/add'); ?>"><i class="icon-font"></i>新增管理员</a>
                        

                    </div>
                </div>
                <div class="result-content">
                    <table class="result-tab" width="100%">
                        <tr>
                            <th width="4%">ID</th>
                            <th>管理员名称</th>
                            <th width="8%">操作</th>
                        </tr>

                         <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                        <tr>
                            <td width="4%"><?php echo $vo['id']; ?> </td>
                            <td title="admin1"><?php echo $vo['username']; ?>                            </td>
                            <td width="10%">

                                 <a class="link-update" href="<?php echo url('Admin/alter',['id'=>$vo['id']]); ?>">修改</a>

                                  <?php if(($vo['id'] != 1)): ?>
                                  
                                   <a class="link-del" onclick="return confirm('你要删除该管理员吗？');" href="<?php echo url('Admin/del',['id'=>$vo['id']]); ?>">删除</a>
                                
                            <?php endif; ?>

                              
                                


                               
                            </td>
                        </tr>
                       <?php endforeach; endif; else: echo "" ;endif; ?>

                    </table>
                    <div class="list-page"><div>    </div></div>
                </div>
            </form>
        </div>
    </div>
    <!--/main-->



    <!--/main-->
</div>

<script type="text/javascript">

    var um = UM.getEditor('content');
   

    //上传图片
    $('#pic').change(function(event) {
        var formData = new FormData();
        formData.append("file", $(this).get(0).files[0]);
        $.ajax({
            url:'/oneblog/public/admin/Article/upload',
            type:'POST',
            data:formData,
            cache: false,
            contentType: false,    //不可缺
            processData: false,    //不可缺
            success:function(data){
                //console.log(data);
                var path='/oneblog/public/static/uploads/'+data;
                $('.picimgs').attr('src',path); 
                $("#articeimg").val(data);
             //  $('#pic').val(data); 
            }
        });
    });



</script>


</body>
</html>